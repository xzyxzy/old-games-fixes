-- Ski Doo X-Team Racing "Time Limit Exceeded" Fix

Fixes error when computer date is set to 2021 and beyond.
For v 1.2 ver (shown in top left in red letters when starting game).

-- xzy