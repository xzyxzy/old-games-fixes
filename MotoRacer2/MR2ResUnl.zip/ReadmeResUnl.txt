--Moto Racer 2 Resolution Unlock
Unlocks resolutions beyond 1024x768

Use with GoG release.
Replace moto.exe

--xzy