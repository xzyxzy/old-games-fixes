-- Moto Racer Widescreen FOV Hack

Replace "game.exe" with version you want and stretch game to your screen.

game_169.EXE - 16:9 Aspect Ratio
game_1610.EXE - 16:10 Aspect Ratio
game_219.EXE - 21:9 Aspect Ratio
game_329.EXE - 32:9 Aspect Ratio

Based on GOG executable.

-- xzy