-- Road Rash (1996) Widescreen Hack

Forces game to render in 854x480. Don't forget to use cnc-ddraw.
NOTE: Background and sky has some issues.

-- xzy